# LocaleShot Customer-Facing Product Notes

## Core Flow

1. Open the macOS app.
2. Choose Continue, New Project, or an archived snapshot in Project Picker.
3. Open the target iOS app in Simulator.
4. In Project, click Attach Simulator.
5. Select the detected installed app if needed.
6. Open Languages from the sidebar, top status strip, or Project card and choose readable language names.
7. In Record Flow, click Open Target App, then Start Recording.
8. Navigate in the real Simulator window, not the preview.
9. Capture each checkpoint with a clear name.
10. Click Generate or Regenerate from the sidebar, Project screen, Generate screen, or Generated Screenshots panel. Then Review generated screenshots and drift warnings.

## Customer-Facing Principles

- Keep bundle IDs, simulator UDIDs, launch arguments, config files, and terminal commands out of the default UI.
- Treat paywalls, modals, permission prompts, and slow transitions as recoverable review states.
- Make every generated screenshot traceable back to a recorded checkpoint.
- Keep the floating recorder available while the Simulator is in focus.
- Always offer undo, reset, retry, project archive, and output-folder actions in visible places.
- Do not clear a recorded flow when attaching a Simulator. Clearing belongs to Reset Flow or New Project.

## Support And Diagnostics

The app can export a diagnostics file from Run History. It includes selected simulator, app, languages, checkpoint count, and run logs.

## Project Management

The app opens with Project Picker, similar to Xcode's launcher. Continue opens the current project, New Project archives the current setup and starts clean, and archived snapshots can be restored. The Project screen remains the command center for attaching the current Simulator, opening the target app, changing languages, choosing output folders, archiving project JSON, and restoring snapshots.

Each project gets an app-specific output folder by default. This prevents screenshots from one app project from appearing in another app project's review gallery.

## Commercialization Hooks

The current UI includes a workspace/license area and diagnostics export. A future licensing layer should gate batch generation limits, not local recording or review.

## Release Packaging

GitHub release packaging is handled by `scripts/package-github-release.sh`. The script creates a zipped `.app` and checksum, and can optionally notarize when `CODESIGN_IDENTITY` and `NOTARY_PROFILE` are provided.
