# LocaleShot

<p align="center">
  <img src="docs/hero.svg" alt="LocaleShot records one Simulator flow and generates localized screenshots" width="100%">
</p>

LocaleShot records one iOS Simulator screenshot flow and replays it across App Store locales.

It is built for raw localized app UI screenshots. It does not add device frames, marketing layouts, App Store Connect uploads, or AI-driven screen discovery.

## Who It Is For

LocaleShot is currently free for indie iOS developers who need localized screenshots without maintaining fragile YAML scripts by hand.

## Requirements

- macOS 13 or newer
- Latest stable Xcode
- iOS Simulator runtime installed
- Target app installed in a booted Simulator
- Accessibility permission for recording clicks in the real Simulator window

## Install From Public Download Repo

Download the public beta from the download-only repo:

https://github.com/Karniej/LocaleShot-Releases

1. Download `LocaleShot-0.1.0-macOS-arm64.zip`:
   `https://raw.githubusercontent.com/Karniej/LocaleShot-Releases/main/downloads/LocaleShot-0.1.0-macOS-arm64.zip`
2. Unzip it.
3. Move `LocaleShot.app` to `/Applications`.
4. Open it. The public beta may be blocked by macOS Gatekeeper until the app is Developer ID notarized.
   - First try right-clicking `LocaleShot.app` and choosing `Open`.
   - If macOS still blocks it, go to `System Settings` > `Privacy & Security` and click `Open Anyway` for LocaleShot.

The beta release is free for indie developers.

## First Run

1. Open LocaleShot.
2. Click `Allow` in the Start Here panel and grant Accessibility permission in macOS System Settings.
3. Open your iOS app in Simulator.
4. Click `Attach`.
5. Click `Choose` and select the detected installed app.
6. Click `Languages` and choose App Store locales.
7. Click `Record`, then `Start Recording`.
8. Navigate in the real Simulator window.
9. Click `Capture Checkpoint` for each screen you need. To enter text, focus the text field in Simulator, then use LocaleShot's `Type` control so the typed text is recorded and replayed.
10. Click `Generate`.

Generated screenshots are saved in the project output folder and shown in the Review gallery.

If the app crashes, click `Export Diagnostics` after reopening LocaleShot. The exported file includes project state, run logs, and recent local LocaleShot crash report excerpts if macOS created any.

## README Hero Image

The committed hero image is `docs/hero.svg`. A prompt for generating a polished replacement image is in [docs/HERO_PROMPT.md](docs/HERO_PROMPT.md).

## Build Locally

```sh
swift build
```

Run the desktop app in development:

```sh
swift run localeshot-app
```

Run the CLI:

```sh
swift run localeshot doctor
swift run localeshot devices
swift run localeshot init screenshots.yaml
swift run localeshot run screenshots.yaml
```

## Package A Local App

```sh
./scripts/package-macos-app.sh
open "dist/LocaleShot.app"
```

This creates an ad-hoc signed local build by default.

## Create Download Artifacts

Recommended public release flow:

```sh
APP_VERSION="0.1.0" BUILD_NUMBER="1" NOTARY_PROFILE="notarytool-profile" ./scripts/release-xcode.sh
```

This generates `LocaleShot.xcodeproj` from `project.yml`, archives the macOS app with Xcode, exports it with Developer ID signing, notarizes it, staples the ticket, and writes:

- `dist/LocaleShot-0.1.0-macOS-arm64.zip`
- `dist/LocaleShot-0.1.0-macOS-arm64.zip.sha256`

The Xcode flow matches the Splonk release pattern and is the right path for public macOS distribution.

Legacy direct SwiftPM packaging is still available for local testing:

```sh
./scripts/package-github-release.sh
```

Outputs:

- `dist/LocaleShot-0.1.0-macOS-arm64.zip`
- `dist/LocaleShot-0.1.0-macOS-arm64.zip.sha256`

To sign with Developer ID:

```sh
CODESIGN_IDENTITY="Developer ID Application: Your Name (TEAMID)" ./scripts/package-github-release.sh
```

To notarize with an existing notarytool keychain profile:

```sh
CODESIGN_IDENTITY="Developer ID Application: Your Name (TEAMID)" \
NOTARY_PROFILE="your-notary-profile" \
./scripts/package-github-release.sh
```

To notarize with an App Store Connect API key:

```sh
CODESIGN_IDENTITY="Developer ID Application: Your Name (TEAMID)" \
NOTARY_KEY_PATH="/path/to/AuthKey_ABC123DEFG.p8" \
NOTARY_KEY_ID="ABC123DEFG" \
NOTARY_ISSUER_ID="00000000-0000-0000-0000-000000000000" \
./scripts/package-github-release.sh
```

Notarization still requires a `Developer ID Application` signing certificate. An `Apple Development` certificate is not enough for public macOS distribution outside the App Store.

Then copy the ZIP and checksum into the public download-only repo:

```sh
cp dist/LocaleShot-0.1.0-macOS-arm64.zip ../LocaleShot-Releases/downloads/
cp dist/LocaleShot-0.1.0-macOS-arm64.zip.sha256 ../LocaleShot-Releases/downloads/
cd ../LocaleShot-Releases
git add downloads
git commit -m "Update LocaleShot download"
git push origin main
```

## Privacy

LocaleShot is local-only. It does not collect telemetry, analytics, accounts, or uploaded screenshots. See [PRIVACY.md](PRIVACY.md).

## License

Free public beta license. Source code remains private. See [LICENSE](LICENSE).
